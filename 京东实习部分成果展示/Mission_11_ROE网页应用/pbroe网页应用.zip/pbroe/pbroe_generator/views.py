# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from fake_pb import fake_generator

# Create your views here.
from django.http import HttpResponse


def index(request):
    if request.method == "POST":
        d = request.POST.dict()

        return HttpResponse(str(d))

    dfs = fake_generator(1, 2, 3)




    return  render(request,'pbroe_generator/index.html',{'dfs':dfs})