# -*- coding: utf-8 -*-
import pandas as pd
import os
os.chdir(os.path.dirname(os.path.realpath(__file__)))


def fake_generator(y, m, d):

    names = ["Selected", "行业筛选", "Org_data1", "Org_data2", "Pool1", "Pool2"]
    dfs = map(lambda x:pd.read_excel('PB_ROE筛选结果.xlsx',x),range(len(names)))
    df_column_values_list = []
    for i in range(len(dfs)):
        df_column_values_list.append(
            ["#"+names[i],names[i], list(dfs[i].columns), map(lambda x: list(x), list(dfs[i].itertuples()))])

    return df_column_values_list  # columns,index,values用来render,tolist()